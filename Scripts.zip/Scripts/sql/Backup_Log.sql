USE MASTER
GO
EXECUTE dbo.DatabaseBackup
@Databases = 'USER_DATABASES',
@Directory = 'C:\Backup_BD',
@BackupType = 'LOG',
@Verify = 'Y',
@Checksum = 'Y',
@CleanupTime = 48